﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class admin_CoursesUpdate : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Constr"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
    }
    protected void btnupdate_Click(object sender, EventArgs e)
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("sp_course", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@corname", txtcorname.Text.ToString());
        cmd.Parameters.AddWithValue("@corfee", txtcorfee.Text.ToString());
        cmd.Parameters.AddWithValue("@corduration", txtcorduration.Text.ToString());
        cmd.Parameters.AddWithValue("@Action", "insert");
        try
        {
            cmd.ExecuteNonQuery();
            Response.Write("<script>alert('Registered successfully');</script>");
        }
        catch (Exception exc)
        {
            throw exc;
        }
        finally
        {
            con.Close();
        }

    }

    protected void Button1_Click(object sender, EventArgs e)
    {

        txtcorname.Text = "";
        txtcorfee.Text = "";
        txtcorduration.Text = "";


        
    }
}