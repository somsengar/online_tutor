﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;


public partial class admin_coursedetails : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            showcourse();
        }
      
    }
    public DataTable showcourse()
    {
        try
        {
            SqlCommand cmd = new SqlCommand("select * from tb_course", con);

            con.Open();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            grdcourse.DataSource = dt;
            grdcourse.DataBind();
            return dt;
        }
        catch (Exception exc)
        {
            throw exc;
        }
        finally
        {
            con.Close();
        }
    }


   
    protected void grdcourse_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        Label cid = grdcourse.Rows[e.RowIndex].FindControl("lblcid") as Label;
        try
        {
            SqlCommand cmd = new SqlCommand("sp_course", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@id", Convert.ToInt32( cid.Text.ToString()));
            cmd.Parameters.AddWithValue("@action", "delete");
            con.Open();
            cmd.ExecuteNonQuery();
            Response.Write("<script>alert('Data Deleted Successfully');</script>");
            con.Close();
            grdcourse.EditIndex = -1;
            showcourse();
        }
        catch (Exception exc)
        {
            throw exc;
        }
      
    }

    protected void grdcourse_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        Label cid = grdcourse.Rows[e.RowIndex].FindControl("lblcid") as Label;
        TextBox cname = grdcourse.Rows[e.RowIndex].FindControl("txtcname") as TextBox;
        TextBox fees = grdcourse.Rows[e.RowIndex].FindControl("txtcfees") as TextBox;
        TextBox duration = grdcourse.Rows[e.RowIndex].FindControl("txtduration") as TextBox;
        try
        {
            SqlCommand cmd = new SqlCommand("sp_course", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@id", cid.Text.ToString());
            cmd.Parameters.AddWithValue("@corname", cname.Text.ToString());
            cmd.Parameters.AddWithValue("@corfee", fees.Text.ToString());
            cmd.Parameters.AddWithValue("@corduration", duration.Text.ToString());
            cmd.Parameters.AddWithValue("@Action", "update");
            con.Open();
            cmd.ExecuteNonQuery();
            Response.Write("<script>alert('Data Updated Successfully');</script>");
            con.Close();
            grdcourse.EditIndex = -1;
            showcourse();
        }
        catch (Exception exc)
        {
            throw exc;
        }
        finally
        {
            con.Close();
        }
    }

    protected void grdcourse_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        grdcourse.EditIndex = -1;
        showcourse();
    }

    protected void grdcourse_RowEditing(object sender, GridViewEditEventArgs e)
    {
 
        showcourse();
        grdcourse.EditIndex = -1;   
}
}