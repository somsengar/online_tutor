﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

public partial class login : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Constr"].ConnectionString);
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        try
        {
            string ltype = ddllogintype.Text;
            con.Open();
            if (ltype == "Admin Login")
            {
                string query = "select * from tblImages where email= '" + txtemail.Text.ToString() + "'and password='" + txtpassword.Text.ToString() + "'";
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataReader sdr = cmd.ExecuteReader();
                if (sdr.Read())
                {
                    Session["username"] = txtemail.Text.ToString();
                    Response.Redirect("/admin/dashboard.aspx");
                    Response.Write("<script>alert('Login successfully');</script>");
                    Session.RemoveAll();

                }
                else
                {
                    lblerrormsg.Text = "userid and password is incorrect! try again";
                }
            }

            if (ltype == "Student Login")
            {
                string query = "select * from tb_StudentRegister where email= '" + txtemail.Text.ToString() + "'and password='" + txtpassword.Text.ToString() + "'";
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataReader sdr = cmd.ExecuteReader();
                if (sdr.Read())
                {
                    Session["username"] = txtemail.Text.ToString();
                    Response.Redirect("/StudentProfile.aspx");
                    Response.Write("<script>alert('Login successfully');</script>");
                    Session.RemoveAll();

                }
                else
                {

                    lblerrormsg.Text = "userid and password is incorrect! try again";
                }
            }
            if (ltype == "Teacher Login")
            {
                string query = "select * from tb_teachregister where email= '" + txtemail.Text.ToString() + "'and password='" + txtpassword.Text.ToString() + "'";
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataReader sdr = cmd.ExecuteReader();
                if (sdr.Read())
                {
                    Session["username"] = txtemail.Text.ToString();
                    Response.Redirect("/TeacherProfile.aspx");
                    Response.Write("<script>alert('Login successfully');</script>");
                    Session.RemoveAll();

                }
                else
                {
                    lblerrormsg.Text = "userid and password is incorrect! try again";
                }
            }

        }
        catch (Exception exc)
        {
            throw exc;
        }
        finally
        {
            con.Close();
        }

    }
    protected void clrbtn_Click(object sender, EventArgs e)
    {
        ddllogintype.Text= "--Select Login Type--";
        txtemail.Text = "";
        txtpassword.Text = "";
        
    }
}
